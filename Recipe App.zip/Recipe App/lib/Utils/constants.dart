import 'package:flutter/material.dart';

const kbackgroundColor = Color(0xffeff1f7);
const kprimaryColor = Color(0xff568A9F);
const kBannerColor = Color(0xff579f8c);
